# ant-learn-algorithm

## 代码的打开方式

不论你是windows、mac、linux，推荐去下载anaconda  
地址为：
https://www.anaconda.com/

下载好之后，进入你电脑的命令行，如果是windows就是cmd命令行，mac/linux就是系统命令行

然后使用cd命令切换到这个下载好的代码目录

在里面输入：jupyter notebook
就能打开Python网页版执行器，可以play这个代码了

## 欢迎关注我的微信公众号

公众号会持续分享Python基础、算法、数据分析、大数据处理、机器学习、推荐系统等领域的干货

<img src="./weixin_gzh_erweima.jpg" />

## 送给大家一句话
学习就像游泳，不要看别人游的多么好，自己得下水才能学会
